<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Reset</title>
</head>
<body>
    <span><b>Hi</b></span> <span style="color:gray">{{$data['name']}},</span>
    <p>
        Welcome to our E-Commerce Application. <br/>Now you are our new registered customer.<br/>
        <br/>
        Thanks for registering!
        <br/>
        <br/>
        <b style="color:green">Best Regards,</b><br/>
        Md Anwar Hossain
    </p>
</body>
</html>